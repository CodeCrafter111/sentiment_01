// ContextProvider.js

import React, { createContext, useState } from 'react';

// Create a new context using React's createContext() function
const MyContext = createContext();

// Create the context provider component
const ContextProvider = ({ children }) => {
  // Define state variables or any other logic specific to your context
  const [value, setValue] = useState('');

  // You can define your context provider logic here

  // Provide the context value to the children components using MyContext.Provider
  return (
    <MyContext.Provider value={{ value, setValue }}>
      {children}
    </MyContext.Provider>
  );
};

// Export the context (MyContext) and the context provider (ContextProvider) for use in other components
export { MyContext, ContextProvider };
