import React, { useState } from "react";
import Header from "./components/Header";
import PredictionResult from "./components/PredictionResult";
import Backdrop from "@mui/material/Backdrop";
import { ContextProvider } from "./contexts/ContextProvider";
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from "chart.js";
import { Pie } from "react-chartjs-2";
import { Container, Grid, Paper, Typography } from "@mui/material";
import { TextareaAutosize } from "@mui/base/TextareaAutosize";
import CircularProgress from "@mui/material/CircularProgress";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Menu from "@mui/material/Menu";
import MenuIcon from "@mui/icons-material/Menu";
import Button from "@mui/material/Button";
import MenuItem from "@mui/material/MenuItem";
import AdbIcon from "@mui/icons-material/Adb";
import SentimentVerySatisfiedIcon from "@mui/icons-material/SentimentVerySatisfied";
import Alert from "@mui/material/Alert";
// eslint-disable-next-line
import CheckIcon from '@mui/icons-material/Check';


import "./App.css";

ChartJS.register(ArcElement, Tooltip, Legend);

function App() {
  const [text, setText] = useState("");
  const [prediction, setPrediction] = useState("");
  const [loading, setLoading] = useState(false);
  const pages = ["Home Page", "About Us"];
  const [originaltext, setOriginaltext] = useState("");

  const handleInputChange = (event) => {
    setText(event.target.value);
  };

  const [anchorElNav, setAnchorElNav] = useState(false);

  const handleOpenNavMenu = (event) => {
    setAnchorElNav(event.currentTarget);
  };

  const handleCloseNavMenu = () => {
    setAnchorElNav(false);
  };

  const [percentageData, setPercentageData] = useState([]);

  const chartdata = {
    labels: ["Positive", "Negative"],
    datasets: [
      {
        label: "Sentiment Percentage",
        data: percentageData,
        backgroundColor: ["RGBA(0, 180, 0, 1)", "rgba(220, 0, 0)"],
        borderColor: ["RGBA(0, 180, 0, 1)", "rgba(220, 0, 0)"],
        borderWidth: 1,
      },
    ],
  };

  const handlePredict = () => {
    setLoading(true);
    fetch("http://localhost:5000/analyze_sentiment", {
      // Updated URL
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ text }),
    })
      .then((response) => response.json())
      .then((data) => {
        setOriginaltext(text);
        setPrediction(data.sentiment);
        setPercentageData([data.positive_percent, data.negative_percent]);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error:", error);
        setLoading(false);
      });
  };

  return (
    <ContextProvider>
      <AppBar position="static">
        <Container maxWidth="xxl">
          <Toolbar disableGutters>
            <SentimentVerySatisfiedIcon
              sx={{ display: { xs: "none", md: "flex" }, mr: 1 }}
            />
            <Typography
              variant="h6"
              noWrap
              component="a"
              href="#app-bar-with-responsive-menu"
              sx={{
                mr: 2,
                display: { xs: "none", md: "flex" },
                fontFamily: "monospace",
                fontWeight: 700,
                letterSpacing: ".3rem",
                color: "inherit",
                textDecoration: "none",
              }}
            >
              OpinionMosaic
            </Typography>

            <Box sx={{ flexGrow: 1, display: { xs: "flex", md: "none" } }}>
              <IconButton
                size="large"
                aria-label="account of current user"
                aria-controls="menu-appbar"
                aria-haspopup="true"
                onClick={handleOpenNavMenu}
                color="inherit"
              >
                <MenuIcon />
              </IconButton>
              <Menu
                id="menu-appbar"
                anchorEl={anchorElNav}
                anchorOrigin={{
                  vertical: "bottom",
                  horizontal: "left",
                }}
                keepMounted
                transformOrigin={{
                  vertical: "top",
                  horizontal: "left",
                }}
                open={anchorElNav}
                onClose={handleCloseNavMenu}
                sx={{
                  display: { xs: "block", md: "none" },
                }}
              >
                {pages.map((page) => (
                  <MenuItem key={page} onClick={handleCloseNavMenu}>
                    <Typography textAlign="center">{page}</Typography>
                  </MenuItem>
                ))}
              </Menu>
            </Box>
            <AdbIcon sx={{ display: { xs: "flex", md: "none" }, mr: 1 }} />
            <Typography
              variant="h5"
              noWrap
              component="a"
              href="#app-bar-with-responsive-menu"
              sx={{
                mr: 2,
                display: { xs: "flex", md: "none" },
                flexGrow: 1,
                fontFamily: "monospace",
                fontWeight: 700,
                letterSpacing: ".3rem",
                color: "inherit",
                textDecoration: "none",
              }}
            >
              LOGO
            </Typography>
            <Box sx={{ flexGrow: 1, display: { xs: "none", md: "flex" } }}>
              {pages.map((page) => (
                <Button
                  key={page}
                  onClick={handleCloseNavMenu}
                  sx={{ my: 2, color: "white", display: "block" }}
                >
                  {page}
                </Button>
              ))}
            </Box>
          </Toolbar>
        </Container>
      </AppBar>
      <Backdrop open={loading}>
        <CircularProgress color="inherit" />
      </Backdrop>{" "}
      {/* Wrap your component with ContextProvider */}
      <div className="App">
        <Container maxWidth="md">
        <Header />
          <Paper elevation={3} className="paper">
            <Grid container spacing={3} justifyContent="center">
              <Grid item xs={12}>
                <Typography variant="h6" align="center">
                  Enter text for Analysis
                </Typography>
              </Grid>
              <Grid item xs={12} align="center">
                <TextareaAutosize
                  value={text}
                  style={{ fontFamily: "'IBM Plex Sans', sans-serif" }}
                  onChange={handleInputChange}
                />
              </Grid>
              <Grid item xs={12} align="center">
                <Button
                  variant="contained"
                  style={{ fontFamily: "'IBM Plex Sans', sans-serif" }}
                  onClick={handlePredict}
                >
                  Predict
                </Button>
              </Grid>
              {prediction && <Grid item xs={10}>
                <PredictionResult prediction={prediction} />
              </Grid>}
              {percentageData?.length > 0 && (
                <Grid item xs={5} >
                  <Alert severity="success" style={{marginBottom: "10px"}}>Original text</Alert>
                  <Typography variant="h6">{originaltext}</Typography>
                </Grid>
              )}
              {percentageData?.length > 0 && (
                <Grid item xs={5}>
                  <Alert severity="success" style={{marginBottom: "10px"}}>Prediction Percentage Chart</Alert>
                  <Pie data={chartdata} />
                </Grid>
              )}
            </Grid>
          </Paper>
        </Container>
      </div>
    </ContextProvider>
  );
}

export default App;