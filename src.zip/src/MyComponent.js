// MyComponent.js

import React from 'react';

const MyComponent = () => {
  return (
    <div>
      <h2>This is My Component</h2>
      <p>This is where you can add your custom component content.</p>
    </div>
  );
};

export default MyComponent;
