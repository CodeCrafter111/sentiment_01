import React, { useState } from 'react';
import Header from './components/Header';
import TextInput from './components/TextInput';
import PredictButton from './components/PredictButton';
import PredictionResult from './components/PredictionResult';
import { Container, Grid, Paper, Typography } from '@mui/material';
import './App.css';

function App() {
  const [text, setText] = useState('');
  const [prediction, setPrediction] = useState('');

  const handleInputChange = (event) => {
    setText(event.target.value);
  };

  const handlePredict = () => {
    // Make a POST request to backend for sentiment analysis
    fetch('http://localhost:5000/analyze_sentiment', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ text })
    })
    .then(response => response.json())
    .then(data => {
      // Update the prediction state with the received sentiment
      setPrediction(data.sentiment);
    })
    .catch(error => {
      console.error('Error:', error);
    });
  };

  return (
    <div className="App">
      <Header />
      <Container maxWidth="sm">
        <Paper elevation={3} className="paper">
          <Grid container spacing={3} justifyContent="center">
            <Grid item xs={12}>
              <Typography variant="h6" align="center">
                Enter text for Analysis
              </Typography>
            </Grid>
            <Grid item xs={12}>
              <TextInput value={text} onChange={handleInputChange} />
            </Grid>
            <Grid item xs={12} align="center">
              <PredictButton onClick={handlePredict} />
            </Grid>
            <Grid item xs={12}>
              <PredictionResult prediction={prediction} />
            </Grid>
          </Grid>
        </Paper>
      </Container>
    </div>
  );
}

export default App;
