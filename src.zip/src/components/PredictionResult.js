import React from "react";
import { Typography } from "@mui/material";
import {Alert} from "@mui/material";

function PredictionResult({ prediction }) {
  return (
    <div style={{ marginBottom: "20px" }}>
      <Alert severity="success">Prediction Result</Alert>
      <Typography variant="h6" align="center" style={{textTransform: "capitalize", marginTop: "10px"}}>
        {prediction}
      </Typography>
    </div>
  );
}

export default PredictionResult;