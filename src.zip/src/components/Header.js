// import React from 'react';

// function Header() {
//   return (
//     <header>
//       <centre>
//       <h1>Sentiment Analysis  </h1>
//       </centre>
//     </header>
//   );
// }

// export default Header;

import React from 'react';

function Header() {
  return (
    <header style={{ textAlign: 'center' }}>
      <h1>Sentiment Analysis</h1>
    </header>
  );
}

export default Header;
