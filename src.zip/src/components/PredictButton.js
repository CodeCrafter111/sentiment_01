import React from 'react';

function PredictButton({ onClick }) {
  return (
    <button onClick={onClick}>
      Predict
    </button>
  );
}

export default PredictButton;
