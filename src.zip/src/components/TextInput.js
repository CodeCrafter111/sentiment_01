import React from 'react';

function TextInput({ value, onChange }) {
  return (
    <input
      type="text"
      value={value}
      onChange={onChange}
      placeholder="Enter text..."
    />
  );
}

export default TextInput;
